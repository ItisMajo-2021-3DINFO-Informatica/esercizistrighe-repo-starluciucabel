﻿using System;

namespace esercizio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("esercizio sulle stringhe 3");
            string parola = "";
            int contaparole = 0;
            while (parola != "fine")
            {
                Console.WriteLine("inserisci una parola");
                parola = Console.ReadLine();
                char prima = parola[0];
                char ultima = parola[lunghezza - 1];
                int lunghezza = parola.Length;
                if (prima == ultima)
                {
                    contaparole++;
                }
                Console.WriteLine("ci sono parole che iniziano con" + parola+"e finiscono"+ultima);
            }
        }
    }
}
